package util;

public class TestUtil {

	public static long Page_Load_Timeout=20;
	public static long Implicit_Wait=10;
	
}
